<?php

require_once '../app.php';



// UserController::index();

// UserController::show(1);


