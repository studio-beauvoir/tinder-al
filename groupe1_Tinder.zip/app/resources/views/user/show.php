<h1>Salut <?= $viewData['user']->prenomUser ?></h1>
<h1>Salut <?= $viewData['user']->idGenr ?></h1>