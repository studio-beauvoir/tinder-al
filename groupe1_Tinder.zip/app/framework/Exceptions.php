<?php


class RouterException extends \Exception {
    
}

class QueryException extends \Exception {

}