<?php

class Matchs extends Model {

    public static $table="matchs";

    public $columns = [
        'idUserM1',
        'idUserM2'
    ];

}