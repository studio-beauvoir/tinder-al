<?php


class Genre extends Model {

    public static $table = "genre";

    public $columns = [
        'idGenr',
        'libGenr'
    ];
}