<?php
//site name
define('SITE_NAME', 'your-site-name');

//App Root
define('APP_ROOT', dirname(dirname(__FILE__)));

define('URL_ROOT', '/');
define('URL_SUBFOLDER', '');

