# Tinder_AL
Atelier Blog'Art sur une base de données Tinder

## Mise en production
- Créer un fichier env.php à partir du env.example.php
- Importer le fichier sql migration_(...).sql dans la bdd
- Importer le fichier sql seed.sql dans la bdd
- Lancer via wamp le serveur

## Groupe
Groupe 1 : Leïly et Arthaud

## Crédits
- Projet MMI, IUT Bordeaux Montaigne
- Router php : https://grafikart.fr/tutoriels/router-628

